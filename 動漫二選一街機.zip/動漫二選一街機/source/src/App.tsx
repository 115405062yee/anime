import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import type { SeriesId, Round } from './game';
import { chooseWinner, countVotes, createRounds, SERIES } from './game';

type Phase = 'home' | 'play' | 'chest' | 'result' | 'failed';
type Aim = -1 | 0 | 1;

const loadedImagePromises = new Map<string, Promise<void>>();

function preloadImage(source: string): Promise<void> {
  const cached = loadedImagePromises.get(source);
  if (cached) return cached;
  const promise = new Promise<void>((resolve) => {
    const image = new Image();
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      if (typeof image.decode === 'function') void image.decode().catch(() => undefined).then(() => resolve());
      else resolve();
    };
    image.onload = finish;
    image.onerror = () => { if (!settled) { settled = true; resolve(); } };
    image.src = source;
    if (image.complete) finish();
  });
  loadedImagePromises.set(source, promise);
  return promise;
}

function Sparkle({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" aria-hidden="true"><path d="M12 1.5 14.4 9.6 22.5 12l-8.1 2.4L12 22.5l-2.4-8.1L1.5 12l8.1-2.4L12 1.5Z" fill="currentColor" /></svg>;
}

function JoystickIcon() {
  return <svg viewBox="0 0 48 48" aria-hidden="true"><path d="M9 27c0-5 3.7-8 8-8h14c4.3 0 8 3 8 8v6.5c0 3.6-2.7 6.5-6.5 6.5h-17C11.7 40 9 37.1 9 33.5V27Z" fill="currentColor"/><path d="M24 20V11" stroke="currentColor" strokeWidth="5" strokeLinecap="round"/><circle cx="24" cy="8" r="5" fill="currentColor"/><circle cx="31.5" cy="29" r="2" fill="#17172f"/><circle cx="36.5" cy="33.5" r="2" fill="#17172f"/></svg>;
}

function ChestArt({ open = false }: { open?: boolean }) {
  return <svg className={`chest-art${open ? ' is-open' : ''}`} viewBox="0 0 240 190" role="img" aria-label={open ? '開啟的寶箱' : '待開啟的寶箱'}>
    <ellipse cx="120" cy="170" rx="95" ry="11" fill="#29182a" opacity=".18" />
    <g className="chest-lid">
      <path d={open ? 'M38 77 53 30q4-13 18-13h101q13 0 17 13l14 47-24 22H61L38 77Z' : 'M38 73V54q0-38 37-38h90q37 0 37 38v19l-24 20H61L38 73Z'} fill="#ffb93f" stroke="#5c3150" strokeWidth="7" strokeLinejoin="round" />
      <path d={open ? 'M61 80 73 37h95l13 43' : 'M52 58h136'} fill="none" stroke="#ffe285" strokeWidth="8" strokeLinecap="round" />
      <path d={open ? 'M102 70h36' : 'M101 57h38'} stroke="#ff507b" strokeWidth="9" strokeLinecap="round" />
    </g>
    <path d="M35 82h170v68q0 14-14 14H49q-14 0-14-14V82Z" fill="#e77a3e" stroke="#5c3150" strokeWidth="7" strokeLinejoin="round" />
    <path d="M40 99h160M40 140h160" stroke="#ffc35a" strokeWidth="9" />
    <path d="M58 82v82m124-82v82" stroke="#854663" strokeWidth="10" />
    <path d="M104 102q16-10 32 0v36q-16 10-32 0v-36Z" fill="#fff0a8" stroke="#5c3150" strokeWidth="6" />
    <circle cx="120" cy="120" r="5" fill="#ff507b" />
    {open && <g className="chest-sparkles" fill="#fff178"><path d="m70 16 5 14 14 5-14 5-5 14-5-14-14-5 14-5zm106 0 4 11 11 4-11 4-4 11-4-11-11-4 11-4z"/><circle cx="37" cy="42" r="4"/><circle cx="204" cy="59" r="4"/></g>}
  </svg>;
}

function Header({ phase, onHome }: { phase: Phase; onHome: () => void }) {
  return <header className="topbar">
    <button className="brand" onClick={onHome} aria-label="回首頁">
      <span className="brand-mark"><JoystickIcon /></span>
      <span className="brand-word">ANIME <b>PICK!</b><small>盲選街機俱樂部</small></span>
    </button>
    <div className="topbar-right">
      <span className="free-pill"><i /> FREE PLAY</span>
      {phase !== 'home' && <button className="mini-home" onClick={onHome}>↺ <span>重新開始</span></button>}
      <span className="coin-chip"><span>1P</span> PLAYER</span>
    </div>
  </header>;
}

function Home({ playerName, setPlayerName, aim, startSelected, onAim, onStart }: { playerName: string; setPlayerName: (name: string) => void; aim: Aim; startSelected: boolean; onAim: (side: Aim) => void; onStart: () => void }) {
  const joystickRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const selectAt = (clientX: number) => {
    if (!joystickRef.current) return;
    const rect = joystickRef.current.getBoundingClientRect();
    onAim((clientX - rect.left) / rect.width < 0.5 ? -1 : 1);
  };
  const onPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    dragging.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    selectAt(event.clientX);
  };
  const onPointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (dragging.current) selectAt(event.clientX);
  };
  const onPointerUp = () => { dragging.current = false; };
  return <main className="home-wrap home-arcade-wrap">
    <div className="home-spark spark-a"><Sparkle /></div><div className="home-spark spark-b"><Sparkle /></div>
    <div className="eyebrow home-kicker"><span className="eyebrow-star">✦</span> INSERT COIN · PLAYER 01 · FREE PLAY</div>
    <section className="arcade-visual home-machine" aria-label="動漫極限二選一街機遊戲機">
      <div className="cabinet-halo" aria-hidden="true" />
      <div className="arcade-cabinet home-console">
        <div className="cabinet-marquee"><span className="marquee-small">OSHI PICK MACHINE · PLAYER 01</span><div><b>ANIME</b><i>PICK!</i></div><span className="marquee-lights"><i /><i /><i /><i /><i /></span></div>
        <div className="cabinet-bezel"><div className="cabinet-screen home-screen">
          <span className="screen-corner-tag">INSERT YOUR NAME TO PLAY</span>
          <h1 className="screen-title home-screen-title">動漫極限<br /><b>二選一</b></h1>
          <p>12 張祕密圖片，找出你的命定動漫！</p>
          <div className="start-consequence" role="note"><strong><span aria-hidden="true">♥ ♥ ♥</span> 每局 3 條命</strong><span>未在 5 秒內選擇就扣 1 命；三條命用完就闖關失敗。</span></div>
          <label className="player-name-field"><span>玩家名稱</span><input value={playerName} onChange={(event) => setPlayerName(event.target.value)} maxLength={16} autoComplete="nickname" aria-label="輸入玩家名稱" placeholder="輸入你的遊戲名稱" /></label>
          <button className={`screen-start-option${startSelected ? ' is-selected' : ''}`} onClick={onStart}><span className="screen-start-led" />START<span className="screen-start-cue">{startSelected ? 'SPACE ↵' : '← / →'}</span></button>
          <span className="screen-scanlines" />
        </div></div>
        <div className="cabinet-control-deck home-control-deck">
          <div className={`home-joystick-pad${startSelected ? ' is-selected' : ''}`} ref={joystickRef} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} role="slider" aria-label="左右拖曳街機搖桿選擇 START" aria-valuemin={-1} aria-valuemax={1} aria-valuenow={aim} tabIndex={0} onKeyDown={(event) => { if (event.key === 'ArrowLeft') onAim(-1); if (event.key === 'ArrowRight') onAim(1); }}>
            <span className="home-joystick-base" /><span className="home-joystick-stick" style={{ left: aim === -1 ? '23%' : aim === 1 ? '77%' : '50%', transform: `translateX(-50%) rotate(${aim === -1 ? -24 : aim === 1 ? 24 : 0}deg)` }}><i /></span><span className="home-joystick-arrows">←　→</span>
          </div>
          <button className={`hardware-start${startSelected ? ' is-selected' : ''}`} onClick={onStart} aria-label="選擇或確認 START"><span>START</span><i>▶</i></button>
          <span className="deck-caption">MOVE STICK · PRESS SPACE <b>✦</b></span>
        </div>
        <div className="cabinet-bottom"><span>ANIME PICK!</span><span>✦</span><span>INSERT COIN · FREE</span></div>
      </div>
      <span className="cabinet-spark cabinet-spark-a">✦</span><span className="cabinet-spark cabinet-spark-b">✹</span>
    </section>
    <p className="home-control-hint"><kbd>←</kbd><kbd>→</kbd> 搖桿選 START　·　<kbd>SPACE</kbd> 確定　·　觸控：拖曳搖桿，再點 START</p>
  </main>;
}

function OptionCard({ side, image, active, lost, imageReady, onClick }: { side: 'left' | 'right'; image: string; active: boolean; lost: boolean; imageReady: boolean; onClick: () => void }) {
  return <button className={`option-card ${side}${active ? ' is-active' : ''}${lost ? ' is-loser' : ''}${!imageReady ? ' is-image-loading' : ''}`} onClick={imageReady ? onClick : undefined} disabled={!imageReady} aria-busy={!imageReady} aria-pressed={active} aria-label={imageReady ? `${side === 'left' ? '左' : '右'}側圖片，${active ? '目前已選取' : '搖桿移動至此選擇'}` : '左右圖片同步載入中，請稍候'}>
    <span className="card-frame">
      {imageReady && <img src={image} alt="動漫選項圖片" draggable={false} decoding="sync" />}
      {lost && <><span className="shard shard-top" style={{ backgroundImage: `url("${image}")` }} /><span className="shard shard-bottom" style={{ backgroundImage: `url("${image}")` }} /></>}
      <span className="card-grain" />
      <span className="card-side-label">{side === 'left' ? 'A' : 'B'} <i>{side === 'left' ? 'LEFT' : 'RIGHT'}</i></span>
      <span className="card-glow" />
      {active && <span className="lock-indicator"><span className="lock-orbit" />LOCK ON</span>}
    </span>
    <span className="card-foot"><span className="foot-dot" />{side === 'left' ? '選擇 A' : '選擇 B'}<span className="foot-key">{side === 'left' ? '←' : '→'}</span></span>
  </button>;
}

function Game({
  round, index, picks, aim, setAim, timeLeftMs, health, locked, jolt, imagesReady, onAim, onConfirm, onPrevious, toast,
}: {
  round: Round; index: number; picks: (SeriesId | null)[]; aim: Aim; setAim: (aim: Aim) => void; timeLeftMs: number; health: number; locked: boolean; jolt: boolean; imagesReady: boolean; onAim: (side: Aim) => void; onConfirm: () => void; onPrevious: () => void; toast: string;
}) {
  const padRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const clock = (Math.max(0, Math.ceil(timeLeftMs)) / 1000).toFixed(3).padStart(6, '0');
  const aimFromX = (clientX: number) => {
    if (!padRef.current) return;
    const bounds = padRef.current.getBoundingClientRect();
    const relative = (clientX - bounds.left) / bounds.width;
    if (relative < .44) onAim(-1);
    else if (relative > .56) onAim(1);
    else { setAim(0); }
  };
  const onPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    dragging.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    aimFromX(event.clientX);
  };
  const onPointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (dragging.current) aimFromX(event.clientX);
  };
  const onPointerUp = () => { dragging.current = false; };

  return <main className={`game-wrap${jolt ? ' is-shaking' : ''}`}>
    <div className="game-heading"><div className="game-heading-main"><div className="game-heading-meta"><span className="eyebrow"><span className="live-led" /> ARCADE MATCH · BLIND PICK</span><div className={`lives-hud${health === 1 ? ' lives-critical' : ''}`} role="img" aria-label={`剩餘 ${health} 條命；超時三次即失敗`}><span className="lives-caption"><b>剩餘命數</b><small>超時 3 次即失敗</small></span><span className="lives-pips" aria-hidden="true">{Array.from({ length: 3 }, (_, i) => <i key={i} className={i < health ? 'is-alive' : ''}>♥</i>)}</span><strong className="lives-number">{health}<small> / 3</small></strong></div></div><h1>你會選哪張？<span className="heading-star">✦</span></h1></div>
      <div className="round-counter"><span className="counter-small">ROUND</span><strong>{String(index + 1).padStart(2, '0')}<i> / 12</i></strong></div>
    </div>
    <div className="score-track" aria-label={`第 ${index + 1} 題，共 12 題`}>
      {Array.from({ length: 12 }, (_, i) => <span key={i} className={`${i < index ? 'is-done' : ''}${i === index ? ' is-current' : ''}${picks[i] ? ' has-pick' : ''}`} />)}
    </div>
    <section className="machine-screen">
      <div className="machine-topline"><span><i className="pixel-dot" /> PLAYER 01 <b>·</b> OSHI SELECTOR</span><span className="sound-tag"><span>♪</span> VIBE CHECK</span></div>
      <div className={`versus-hud${timeLeftMs <= 0 ? ' is-expiring' : ''}`}>
        <div className={`duel-bar duel-left${locked && aim === 1 ? ' is-defeated' : ''}${aim === -1 ? ' is-target' : ''}`}><div className="duel-bar-label"><span>A · RED</span><small>{locked && aim === -1 ? 'LOCKED IN' : 'PLAYER A'}</small></div><div className="duel-track"><i className="duel-fill" /></div></div>
        <div className={`timer-box countdown-box${timeLeftMs <= 1500 ? ' is-urgent' : ''}`} aria-label={`剩餘 ${clock} 秒`}><span className="timer-caption">TIME LEFT</span><strong>{clock}</strong><small>SEC</small></div>
        <div className={`duel-bar duel-right${locked && aim === -1 ? ' is-defeated' : ''}${aim === 1 ? ' is-target' : ''}`}><div className="duel-bar-label"><small>{locked && aim === 1 ? 'LOCKED IN' : 'PLAYER B'}</small><span>BLUE · B</span></div><div className="duel-track"><i className="duel-fill" /></div></div>
      </div>
      <div className="match-prompt"><span className="prompt-line" /><span>5 秒內選出本命，倒數精確至毫秒</span><span className="prompt-line" /></div>
      <div className={`card-arena${imagesReady ? '' : ' is-pair-loading'}`} aria-busy={!imagesReady}>
        <OptionCard side="left" image={round.left.image} active={aim === -1} lost={locked && aim === 1} imageReady={imagesReady} onClick={() => onAim(-1)} />
        <div className="versus-mark"><span>VS</span><i>✦</i></div>
        <OptionCard side="right" image={round.right.image} active={aim === 1} lost={locked && aim === -1} imageReady={imagesReady} onClick={() => onAim(1)} />
      </div>
      <div className="control-panel joystick-panel">
        <div className="game-control-copy"><span>街機搖桿</span><small>左右搖選圖，再按確定</small></div>
        <div className="joystick-window" ref={padRef} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} role="slider" aria-label="左右拖曳街機搖桿選擇圖片" aria-valuemin={-1} aria-valuemax={1} aria-valuenow={aim} aria-valuetext={aim === -1 ? '左側 A' : aim === 1 ? '右側 B' : '置中'} tabIndex={0} onKeyDown={(event) => { if (event.key === 'ArrowLeft') onAim(-1); if (event.key === 'ArrowRight') onAim(1); }}>
          <span className="joystick-direction left">← A</span><span className="joystick-direction right">B →</span>
          <span className="joystick-detent left" /><span className="joystick-detent center" /><span className="joystick-detent right" />
          <span className="arcade-stick-handle" style={{ left: aim === -1 ? '20%' : aim === 1 ? '80%' : '50%', transform: `translateX(-50%) rotate(${aim === -1 ? -30 : aim === 1 ? 30 : 0}deg)` }} aria-hidden="true"><i className="arcade-stick-ball"><b /></i><i className="arcade-stick-shaft" /><i className="arcade-stick-socket" /></span>
        </div>
        <button className={`confirm-button${aim !== 0 ? ' can-confirm' : ''}`} onClick={onConfirm} disabled={locked}><span className="space-keycap">SPACE</span><span>確定</span></button>
      </div>
      <div className="machine-bottomline"><span>ARCADE STICK · LEFT / RIGHT</span><span>鍵盤方向鍵或拖曳搖桿，空白鍵確定</span><span>PRESS SPACE TO PICK</span></div>
    </section>
    <div className="game-bottom-row"><button className="prev-button" onClick={onPrevious} disabled={index === 0}>← <span>上一題</span></button><span className="game-miss-hint">每逾時一次扣一命 · 命數歸零即失敗</span><span className="toast-msg" aria-live="polite">{toast}</span></div>
  </main>;
}

function Chest({ onOpen }: { onOpen: () => void }) {
  return <main className="reveal-wrap chest-view">
    <div className="reveal-stars"><Sparkle /><Sparkle /><Sparkle /></div>
    <div className="eyebrow"><span className="eyebrow-star">✦</span> ALL ROUNDS CLEARED · 12 / 12</div>
    <h1>你的本命能量<br /><span>已經收進寶箱！</span></h1>
    <p>咚咚咚——到底是哪一部呢？<br />打開寶箱，揭曉你的命定動漫。</p>
    <button className="chest-button" onClick={onOpen}><ChestArt /><span className="chest-button-label">打開寶箱！<b>↗</b></span></button>
    <div className="chest-footnote"><span>✷</span> PRIZE INSIDE <i>·</i> 本命即將揭曉 <span>✷</span></div>
  </main>;
}

function Failure({ playerName, onRetry, onHome }: { playerName: string; onRetry: () => void; onHome: () => void }) {
  const displayName = playerName.trim() || '玩家';
  return <main className="failure-wrap">
    <div className="failure-stamp" aria-hidden="true">TIME<br />OUT</div>
    <div className="eyebrow failure-kicker"><span className="failure-led" /> GAME OVER · 03 TIMEOUTS</div>
    <h1>闖關失敗</h1>
    <p className="failure-copy">{displayName}累積三次沒有在五秒內做出選擇。</p>
    <div className="failure-title-card"><span>本局獲得稱號</span><strong>猶豫不決</strong><small>TOO SLOW TO CHOOSE</small></div>
    <p className="failure-encouragement">下一局看準就搖，喜歡哪一邊就立刻出手！</p>
    <div className="failure-actions"><button className="failure-retry" onClick={onRetry}>↻ <span>再挑戰一次</span></button><button className="failure-home" onClick={onHome}>回街機首頁</button></div>
  </main>;
}

function Result({ picks, playerName, onAgain, onHome }: { picks: SeriesId[]; playerName: string; onAgain: () => void; onHome: () => void }) {
  const posterRef = useRef<HTMLDivElement>(null);
  const [savingFormat, setSavingFormat] = useState<'png' | 'jpg' | null>(null);
  const [downloadNote, setDownloadNote] = useState('');
  const counts = useMemo(() => countVotes(picks), [picks]);
  const winnerId = useMemo(() => chooseWinner(picks), [picks]);
  const winner = SERIES.find((series) => series.id === winnerId)!;
  const displayName = playerName.trim() || '玩家';
  const total = picks.length || 1;
  const downloadPoster = async (format: 'png' | 'jpg') => {
    if (!posterRef.current || savingFormat) return;
    setSavingFormat(format);
    try {
      const image = posterRef.current.querySelector<HTMLImageElement>('.result-art img');
      if (!image) throw new Error('找不到結果圖片');
      if (!image.complete || image.naturalWidth === 0) {
        await new Promise<void>((resolve, reject) => {
          image.addEventListener('load', () => resolve(), { once: true });
          image.addEventListener('error', () => reject(new Error('結果圖片載入失敗')), { once: true });
        });
      }
      const canvas = document.createElement('canvas');
      canvas.width = 900;
      canvas.height = 1080;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('無法建立圖片');
      context.fillStyle = '#fff7e8';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.strokeStyle = '#edc986';
      context.lineWidth = 5;
      context.strokeRect(14, 14, 872, 1052);
      context.fillStyle = '#f8eddc';
      context.fillRect(18, 18, 864, 104);
      context.font = '900 34px Arial, sans-serif';
      context.fillStyle = '#d84c7f';
      context.fillText('ANIME PICK!', 54, 83);
      context.font = '700 18px Arial, sans-serif';
      context.fillStyle = '#655879';
      context.textAlign = 'right';
      context.fillText('MY NO.1  ✦', 846, 79);
      context.textAlign = 'left';
      context.fillStyle = '#342847';
      context.fillRect(42, 132, 816, 470);
      const scale = Math.max(816 / image.naturalWidth, 470 / image.naturalHeight);
      const imageWidth = image.naturalWidth * scale;
      const imageHeight = image.naturalHeight * scale;
      context.save();
      context.beginPath();
      context.roundRect(42, 132, 816, 470, 12);
      context.clip();
      context.drawImage(image, 42 + (816 - imageWidth) / 2, 132 + (470 - imageHeight) / 2, imageWidth, imageHeight);
      const shade = context.createLinearGradient(0, 420, 0, 602);
      shade.addColorStop(0, 'rgba(20, 15, 31, 0)');
      shade.addColorStop(1, 'rgba(20, 15, 31, .5)');
      context.fillStyle = shade;
      context.fillRect(42, 132, 816, 470);
      context.restore();
      context.fillStyle = '#d4567c';
      context.font = '700 19px Arial, sans-serif';
      context.fillText(`${displayName} 的本命動漫是…`, 56, 657);
      context.fillStyle = '#211b37';
      context.font = '900 48px Arial, sans-serif';
      context.fillText(winner.title, 56, 724);
      context.fillStyle = '#756c82';
      context.font = '22px Arial, sans-serif';
      let captionLine = '';
      let captionY = 772;
      for (const character of Array.from(winner.caption)) {
        const nextLine = captionLine + character;
        if (context.measureText(nextLine).width > 780 && captionLine) {
          context.fillText(captionLine, 56, captionY);
          captionY += 32;
          captionLine = character;
        } else captionLine = nextLine;
      }
      if (captionLine) context.fillText(captionLine, 56, captionY);
      context.fillStyle = '#f4e7d2';
      context.fillRect(42, 852, 816, 137);
      context.fillStyle = '#756c82';
      context.font = '700 18px Arial, sans-serif';
      context.fillText('本命票數', 56, 895);
      context.fillStyle = '#d84c7f';
      context.font = '900 42px Arial, sans-serif';
      context.fillText(`${counts[winnerId]} 票`, 56, 950);
      context.fillStyle = '#90869a';
      context.font = '18px Arial, sans-serif';
      context.fillText(`共完成 ${picks.length} 次直覺選擇`, 56, 978);
      context.strokeStyle = 'rgba(56,41,68,.15)';
      context.beginPath();
      context.moveTo(42, 1008);
      context.lineTo(858, 1008);
      context.stroke();
      context.fillStyle = '#8d8497';
      context.font = '700 15px Arial, sans-serif';
      context.fillText('BLIND PICK  ·  PERFECT MATCH', 56, 1041);
      context.textAlign = 'right';
      context.fillText('#我的動漫本命', 846, 1041);
      context.textAlign = 'left';
      const mime = format === 'png' ? 'image/png' : 'image/jpeg';
      const dataUrl = canvas.toDataURL(mime, 0.92);
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `anime-pick-oshi.${format}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setDownloadNote(`${format.toUpperCase()} 圖片已下載！`);
    } catch {
      setDownloadNote('圖片儲存失敗，請再試一次。');
    } finally {
      setSavingFormat(null);
    }
  };
  return <main className="result-wrap">
    <div className="result-heading"><div className="eyebrow"><span className="eyebrow-star">✦</span> YOUR OSHI HAS BEEN FOUND</div><h1>本命揭曉！</h1><p>{displayName} 的本命動漫是《{winner.title}》！</p></div>
    <div className="result-layout">
      <div className="result-main-card" ref={posterRef}>
        <div className="poster-topline"><span>ANIME PICK!</span><span>MY NO.1 <b>✦</b></span></div>
        <div className="result-art"><img src={winner.images[0]} alt="你的本命動漫畫面" /><span className="winner-stamp">OSHI<br />FOUND!</span><span className="art-bottom-shade" /></div>
        <div className="result-copy"><span className="winner-overline">{displayName} 的本命動漫是…</span><h2>{winner.title}</h2><p>{winner.caption}</p><div className="winner-score"><span>本命票數</span><b>{counts[winnerId]}<small> / {picks.length}</small></b></div>
        </div>
        <div className="poster-bottom"><span>BLIND PICK · PERFECT MATCH</span><b>♥</b><span>#我的動漫本命</span></div>
      </div>
      <section className="vote-breakdown"><div className="breakdown-header"><span>你的本命雷達</span><small>VOTE BREAKDOWN</small></div>
        {SERIES.map((series) => <div className={`vote-line${series.id === winnerId ? ' winner-line' : ''}`} key={series.id}>
          <div className="vote-line-meta"><span>{series.title}{series.id === winnerId && <i> 本命</i>}</span><b>{counts[series.id]}<small> 票</small></b></div>
          <div className="vote-track"><span style={{ width: `${counts[series.id] / total * 100}%`, background: series.accent }} /></div>
        </div>)}
        <div className="tie-note">✦ 若票數相同，以你最後投下的那一票決勝。</div>
        <div className="result-actions download-actions">
          <button className="download-button png-download" onClick={() => void downloadPoster('png')} disabled={savingFormat !== null}>{savingFormat === 'png' ? '製作 PNG…' : '下載 PNG'}</button>
          <button className="download-button jpg-download" onClick={() => void downloadPoster('jpg')} disabled={savingFormat !== null}>{savingFormat === 'jpg' ? '製作 JPG…' : '下載 JPG'}</button>
          <button className="again-button" onClick={onAgain}>↻ <span>再玩一次</span></button>
          <button className="result-home-button" onClick={onHome}>⌂ <span>回首頁</span></button>
        </div>
        <p className="download-note" aria-live="polite">{downloadNote}</p>
      </section>
    </div>
  </main>;
}

export default function App() {
  const [phase, setPhase] = useState<Phase>('home');
  const [rounds, setRounds] = useState<Round[]>(() => createRounds());
  const [roundIndex, setRoundIndex] = useState(0);
  const [readyRound, setReadyRound] = useState<Round | null>(null);
  const [picks, setPicks] = useState<(SeriesId | null)[]>(() => Array<SeriesId | null>(12).fill(null));
  const [aim, setAim] = useState<Aim>(0);
  const [homeAim, setHomeAim] = useState<Aim>(0);
  const [playerName, setPlayerName] = useState('');
  const [timeLeftMs, setTimeLeftMs] = useState(5000);
  const [timerEpoch, setTimerEpoch] = useState(0);
  const [health, setHealth] = useState(3);
  const [locked, setLocked] = useState(false);
  const [jolt, setJolt] = useState(false);
  const [toast, setToast] = useState('');
  const finishTimer = useRef<number | undefined>(undefined);
  const joltTimer = useRef<number | undefined>(undefined);
  const currentRound = rounds[roundIndex] ?? rounds[0];
  const imagesReady = phase === 'play' && readyRound === currentRound;

  const startGame = () => {
    window.clearTimeout(finishTimer.current);
    setRounds(createRounds());
    setPicks(Array<SeriesId | null>(12).fill(null));
    setRoundIndex(0);
    setAim(0);
    setHomeAim(0);
    setTimeLeftMs(5000);
    setTimerEpoch(0);
    setHealth(3);
    setLocked(false);
    setToast('');
    setPlayerName((current) => current.trim().slice(0, 16));
    setPhase('play');
  };
  const restartHome = () => {
    window.clearTimeout(finishTimer.current);
    setPhase('home');
    setAim(0);
    setHomeAim(0);
    setLocked(false);
    setToast('');
  };
  const aimAt = (side: Aim) => {
    if (locked || side === 0 || !imagesReady) return;
    setAim(side);
    setToast('');
  };
  const confirmHomeStart = () => {
    if (homeAim === 0) { setHomeAim(1); return; }
    startGame();
  };
  const confirmChoice = () => {
    if (phase !== 'play' || locked) return;
    if (!imagesReady) return;
    if (aim === 0) { setToast('先左右搖動操縱桿選圖片，再按空白鍵！'); return; }
    const round = rounds[roundIndex];
    const chosen = aim === -1 ? round.left.series : round.right.series;
    setPicks((previous) => { const next = [...previous]; next[roundIndex] = chosen; return next; });
    setLocked(true);
    setToast('選擇已鎖定！');
    finishTimer.current = window.setTimeout(() => {
      setLocked(false);
      setAim(0);
      setTimeLeftMs(5000);
      setToast('');
      if (roundIndex === rounds.length - 1) setPhase('chest');
      else setRoundIndex((current) => current + 1);
    }, 730);
  };
  const goPrevious = () => {
    if (roundIndex <= 0 || locked) return;
    setRoundIndex((current) => current - 1);
    setAim(0);
    setTimeLeftMs(5000);
    setToast('重新選擇上一題');
  };

  useEffect(() => {
    void Promise.all(SERIES.flatMap((series) => series.images).map(preloadImage));
  }, []);

  useEffect(() => {
    if (phase !== 'play' || !currentRound) { setReadyRound(null); return undefined; }
    let cancelled = false;
    const upcomingRound = rounds[roundIndex + 1];
    const sources = [currentRound.left.image, currentRound.right.image];
    if (upcomingRound) sources.push(upcomingRound.left.image, upcomingRound.right.image);
    void Promise.all(sources.map(preloadImage)).then(() => {
      if (!cancelled) setReadyRound(currentRound);
    });
    return () => { cancelled = true; };
  }, [phase, currentRound, rounds, roundIndex]);

  useEffect(() => {
    if (phase !== 'play' || locked || !imagesReady) return undefined;
    let frameId = 0;
    let resetTimer = 0;
    let expired = false;
    const startedAt = performance.now();
    const tick = (now: number) => {
      const remaining = Math.max(0, 5000 - (now - startedAt));
      setTimeLeftMs(remaining);
      if (remaining > 0) { frameId = window.requestAnimationFrame(tick); return; }
      if (expired) return;
      expired = true;
      setHealth(health <= 1 ? 0 : health - 1);
      setJolt(true);
      setToast(health <= 1 ? '三次逾時，闖關失敗！' : '時間到！換下一題');
      joltTimer.current = window.setTimeout(() => setJolt(false), 650);
      resetTimer = window.setTimeout(() => {
        if (health <= 1) { setToast(''); setPhase('failed'); return; }
        setTimeLeftMs(5000);
        setAim(0);
        setToast('');
        if (roundIndex >= rounds.length - 1) { setPhase('chest'); return; }
        setRoundIndex((current) => current + 1);
        setTimerEpoch((current) => current + 1);
      }, 480);
    };
    frameId = window.requestAnimationFrame(tick);
    return () => { window.cancelAnimationFrame(frameId); window.clearTimeout(resetTimer); };
  }, [phase, locked, roundIndex, timerEpoch, imagesReady]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (phase === 'home') {
        const target = event.target as HTMLElement | null;
        const editable = target?.closest('input, textarea, select, [contenteditable="true"]');
        if (editable) {
          if (event.key === 'ArrowLeft') { event.preventDefault(); (editable as HTMLElement).blur(); setHomeAim(-1); }
          if (event.key === 'ArrowRight') { event.preventDefault(); (editable as HTMLElement).blur(); setHomeAim(1); }
          return;
        }
        if (event.key === 'ArrowLeft' || event.key.toLowerCase() === 'a') { event.preventDefault(); setHomeAim(-1); return; }
        if (event.key === 'ArrowRight' || event.key.toLowerCase() === 'd') { event.preventDefault(); setHomeAim(1); return; }
        if (event.code === 'Space' || event.key === ' ') { event.preventDefault(); confirmHomeStart(); }
        return;
      }
      if (phase !== 'play') return;
      if (event.key === 'ArrowLeft' || event.key.toLowerCase() === 'a') { event.preventDefault(); aimAt(-1); }
      if (event.key === 'ArrowRight' || event.key.toLowerCase() === 'd') { event.preventDefault(); aimAt(1); }
      if (event.code === 'Space' || event.key === ' ') { event.preventDefault(); confirmChoice(); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  useEffect(() => () => { window.clearTimeout(finishTimer.current); window.clearTimeout(joltTimer.current); }, []);

  return <div className={`site-shell phase-${phase}`}>
    <div className="background-grid" aria-hidden="true" />
    <Header phase={phase} onHome={restartHome} />
    {phase === 'home' && <Home playerName={playerName} setPlayerName={setPlayerName} aim={homeAim} startSelected={homeAim !== 0} onAim={setHomeAim} onStart={confirmHomeStart} />}
    {phase === 'play' && currentRound && <Game round={currentRound} index={roundIndex} picks={picks} aim={aim} setAim={setAim} timeLeftMs={timeLeftMs} health={health} locked={locked} jolt={jolt} imagesReady={imagesReady} onAim={aimAt} onConfirm={confirmChoice} onPrevious={goPrevious} toast={toast} />}
    {phase === 'chest' && <Chest onOpen={() => setPhase('result')} />}
    {phase === 'result' && <Result picks={picks.filter((pick): pick is SeriesId => pick !== null)} playerName={playerName.trim() || '玩家'} onAgain={startGame} onHome={restartHome} />}
    {phase === 'failed' && <Failure playerName={playerName} onRetry={startGame} onHome={restartHome} />}
    <footer className="site-footer"><span>ANIME PICK! <b>©</b> YOUR HEART, YOUR CHOICE.</span><span>MADE FOR ANIME LOVERS <i>✦</i> PLAY AGAIN, ANYTIME</span></footer>
  </div>;
}
