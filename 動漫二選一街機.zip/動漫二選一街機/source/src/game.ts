export type SeriesId = 'haikyu' | 'apothecary' | 'titan';

export interface AnimeSeries {
  id: SeriesId;
  title: string;
  englishTitle: string;
  caption: string;
  accent: string;
  images: string[];
}

export interface RoundOption {
  image: string;
  series: SeriesId;
}

export interface Round {
  left: RoundOption;
  right: RoundOption;
}

export const SERIES: AnimeSeries[] = [
  {
    id: 'haikyu',
    title: '排球少年!!',
    englishTitle: 'HAIKYU!!',
    caption: '熱血躍上巔峰，心跳就此發球！',
    accent: '#ff8b3d',
    images: ['./images/card-01.webp', './images/card-02.webp', './images/card-03.webp', './images/card-04.webp'],
  },
  {
    id: 'apothecary',
    title: '藥師少女的獨語',
    englishTitle: 'THE APOTHECARY DIARIES',
    caption: '一抹藥香，揭開宮廷裡的真相。',
    accent: '#4cdbb2',
    images: ['./images/card-05.webp', './images/card-06.webp', './images/card-07.webp', './images/card-08.webp'],
  },
  {
    id: 'titan',
    title: '進擊的巨人',
    englishTitle: 'ATTACK ON TITAN',
    caption: '越過高牆，奔向自由的另一端。',
    accent: '#b19cff',
    images: ['./images/card-09.webp', './images/card-10.webp', './images/card-11.webp', './images/card-12.webp'],
  },
];

const getSeries = (id: SeriesId) => SERIES.find((series) => series.id === id)!;

export function createRounds(): Round[] {
  const pairings: [SeriesId, SeriesId][] = [
    ['haikyu', 'apothecary'],
    ['apothecary', 'titan'],
    ['titan', 'haikyu'],
    ['apothecary', 'haikyu'],
    ['titan', 'apothecary'],
    ['haikyu', 'titan'],
    ['titan', 'haikyu'],
    ['haikyu', 'apothecary'],
    ['apothecary', 'titan'],
    ['haikyu', 'titan'],
    ['titan', 'apothecary'],
    ['apothecary', 'haikyu'],
  ];
  const rounds = pairings.map(([first, second], index) => {
    const art = Math.floor(index / 3);
    const a = { image: getSeries(first).images[art], series: first };
    const b = { image: getSeries(second).images[art], series: second };
    return index % 2 === 0 ? { left: a, right: b } : { left: b, right: a };
  });
  // Shuffle only order, retaining exactly four match-ups per pair and equal side exposure.
  for (let i = rounds.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [rounds[i], rounds[j]] = [rounds[j], rounds[i]];
  }
  return rounds;
}

export function countVotes(picks: (SeriesId | null)[]): Record<SeriesId, number> {
  return picks.reduce<Record<SeriesId, number>>(
    (counts, pick) => {
      if (pick) counts[pick] += 1;
      return counts;
    },
    { haikyu: 0, apothecary: 0, titan: 0 },
  );
}

export function chooseWinner(picks: SeriesId[]): SeriesId {
  const counts = countVotes(picks);
  const highest = Math.max(...Object.values(counts));
  const tied = SERIES.filter((series) => counts[series.id] === highest).map((series) => series.id);
  // Predictable tie-break: among tied series, the player's most recent vote wins.
  return [...picks].reverse().find((pick) => tied.includes(pick)) ?? SERIES[0].id;
}
