# ANIME PICK! 動漫二選一街機

## 直接檢視

解壓縮後，直接開啟此資料夾最上層的 **`index.html`**。此頁已將網站使用的 CSS 與 JavaScript 內嵌；12 張遊戲圖片和 favicon 由同資料夾中的相對路徑載入。建議使用最新版 Chrome、Edge 或 Firefox。遊戲本身不需安裝套件，也不需啟動伺服器。

圖片路徑範例：`./images/card-01.webp`、`./images/card-12.webp`。請保留 `images/` 資料夾及圖片檔名，否則遊戲卡片會缺圖。

## 在 VS Code 編輯原始碼

可在 VS Code 開啟此資料夾內的 **`source/`**。原始碼位於 `source/src/`，網站圖片位於 `source/public/images/`。原始碼中圖片路徑範例為 `./images/card-01.webp`。

需要開發伺服器時，在 `source/` 目錄執行：

```bash
pnpm install
pnpm dev
```

然後在瀏覽器開啟 `http://localhost:3000/`。檢查與建置指令：

```bash
pnpm typecheck
pnpm build
```

## 資料夾結構

```text
動漫二選一街機/
├── index.html                 # 可直接點開的獨立遊戲頁，CSS／JavaScript 已內嵌
├── favicon.svg                # 相對路徑圖示
├── images/
│   ├── card-01.webp
│   ├── ...
│   └── card-12.webp
├── source/                    # 可用 VS Code 編輯的 Vite／React／TypeScript 原始碼
│   ├── index.html
│   ├── package.json
│   ├── pnpm-lock.yaml
│   ├── public/images/         # 原始圖片素材
│   └── src/
├── README.md
└── 指令歷史紀錄.md
```

若只想體驗遊戲，開啟最上層的 `index.html` 即可；要改程式請使用 `source/`。